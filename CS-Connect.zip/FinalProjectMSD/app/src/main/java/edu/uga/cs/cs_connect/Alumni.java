package edu.uga.cs.cs_connect;

public class Alumni
{

    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String graduatedDate;
    private String domain;
    private String linkedInProfile;
    private String companyName;
    private CompanyAddress addressDetails;



    public Alumni()
    {

    }

    public Alumni(String firstName, String lastName, String email, String password, String graduatedDate, String linkedInProfile, String domain, String companyName, CompanyAddress addressDetails)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.graduatedDate = graduatedDate;
        this.linkedInProfile=linkedInProfile;
        this.domain = domain;
        this.companyName = companyName;
        this.addressDetails = addressDetails;


    }


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGraduatedDate() {
        return graduatedDate;
    }

    public void setGraduatedDate(String graduatedDate) {
        this.graduatedDate = graduatedDate;
    }

    public String getLinkedInProfile() {
        return linkedInProfile;
    }

    public void setLinkedInProfile(String linkedInProfile) {
        this.linkedInProfile = linkedInProfile;
    }

    public void setAddressDetails(CompanyAddress addressDetails) {
        this.addressDetails = addressDetails;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public CompanyAddress getAddressDetails() {
        return addressDetails;
    }


}
