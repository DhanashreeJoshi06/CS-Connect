package edu.uga.cs.cs_connect;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class Geocoding
{
    private static final String TAG = "Geocode";


    //method to get coordinates
    public void getLatLongFromAddress(final String address, final Context context, final Handler handler)
    {

        Thread thread = new Thread() {

            @Override
            public void run()
            {
                super.run();
                Geocoder geocoder = new Geocoder(context, Locale.getDefault());

                //response
                String res = null;

                try
                {
                    List addressList = geocoder.getFromLocationName(address, 1);
                    if (addressList != null && addressList.size() > 0)
                    {

                        Address address = (Address) addressList.get(0);
                        Log.d("--Address--",""+address);
                        StringBuilder sb = new StringBuilder();
                        sb.append(address.getLatitude()).append(" ");
                        sb.append(address.getLongitude());
                        res = sb.toString();
                    }
                } catch (IOException e) {
                    Log.e(TAG, "--Error Occurred--" + e.getMessage());
                }
                finally {
                    Message message = Message.obtain();
                    message.setTarget(handler);
                    if (res != null)
                    {
                        message.what = 1;
                        Bundle bundle = new Bundle();
                        res = "" + res;
                        bundle.putString("address", res);
                        message.setData(bundle);
                    }
                    else
                    {
                        message.what = 1;
                        Bundle bundle = new Bundle();
                        res = "Address: " + address +
                                "\n Unable to get Latitude and Longitude for this address location.";
                        bundle.putString("address", res);
                        message.setData(bundle);
                    }
                    message.sendToTarget();
                }

            }
        };


        thread.start();



    }
}
