package edu.uga.cs.cs_connect;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AlumniFormActivity extends AppCompatActivity
{
    Button create, validAddr;
    EditText FnameAlum, LnameAlum, passAlum, ConfirmPassAlum, gradDateAlum, emailAlum, companyName,companyAddress;
    Spinner spinnerAlum;
    ProgressBar ProgressBarAlum;
    private FirebaseAuth mAuth;
    Geocoding location;
    String latitude;
    EditText linkedInProfile;
    String longitude;
    DatabaseReference databaseRefAlumni;

    private class GeocodeHandler extends Handler
    {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String locationAddress;
            switch (msg.what) {
                case 1:
                    Bundle bundle = msg.getData();

                    //lat long
                    locationAddress = bundle.getString("address");
                    String coordinates[]=locationAddress.split(" ");
                    latitude=coordinates[0];
                    longitude=coordinates[1];
                    Log.d("lat",latitude);
                    Log.d("long",longitude);
                    break;
                default:
                    locationAddress = null;
            }

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumni_form);
        FirebaseApp.initializeApp(AlumniFormActivity.this);
        mAuth = FirebaseAuth.getInstance();
        validAddr=findViewById(R.id.validAddr);
        databaseRefAlumni= FirebaseDatabase.getInstance().getReference("Alumni");

        String[] arraySpinner = new String[] {
                "Data Science","Cloud", "DevOps Engineer","Big Data","Machine Learning", "Software Engineer", "Mobile Developer"
        };
        spinnerAlum = findViewById(R.id.spn_Alum);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerAlum.setAdapter(adapter);

        FnameAlum = findViewById(R.id.FirstNameAlum);
        LnameAlum = findViewById(R.id.LastnameAlum);
        passAlum = findViewById(R.id.PassAlum);
        ConfirmPassAlum = findViewById(R.id.ConfirmPassAlum);
        emailAlum = findViewById(R.id.emailAlum);
        gradDateAlum = findViewById(R.id.gradDateAlum);
        companyName = findViewById(R.id.ComapnyName);
        companyAddress = findViewById(R.id.CompanyAddress);
        ProgressBarAlum = findViewById(R.id.progressBarAlum);
        create = findViewById(R.id.btn_createAlumni);
        linkedInProfile=findViewById(R.id.linkedinURL);
        location = new Geocoding();
        validAddr.setOnClickListener(new View.OnClickListener()
        {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v)
            {

                String address = companyAddress.getText().toString().trim();
                if (TextUtils.isEmpty(address)) {
                    Toast.makeText(getApplicationContext(), "Enter company's address!", Toast.LENGTH_SHORT).show();
                    return;
                }
                location.getLatLongFromAddress(address,getApplicationContext(),new GeocodeHandler());



                if(!create.isEnabled())
                {


                    create.setBackground(getResources().getDrawable(R.drawable.btn_rounded));
                    create.setEnabled(true);
                }





            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                final String firstName=FnameAlum.getText().toString().trim();
                final String lastName=LnameAlum.getText().toString().trim();
                final String email = emailAlum.getText().toString().trim();
                final String password = passAlum.getText().toString().trim();
                String confirmPassword = ConfirmPassAlum.getText().toString().trim();
                final String graduatedDate=gradDateAlum.getText().toString().trim();
                final String domain= spinnerAlum.getSelectedItem().toString().trim();
                final String company=companyName.getText().toString().trim();
                final String linkedProfile=linkedInProfile.getText().toString();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Enter Password !", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(getApplicationContext(), "Enter Password for Confirmation !", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!TextUtils.equals(password,confirmPassword)) {
                    Toast.makeText(getApplicationContext(), "Enter the same password to confirm!", Toast.LENGTH_SHORT).show();
                    return;
                }

                ProgressBarAlum.setVisibility(View.VISIBLE);
                mAuth.createUserWithEmailAndPassword(email,confirmPassword).addOnCompleteListener(AlumniFormActivity.this, new OnCompleteListener <AuthResult>( ) {
                    @Override
                    public void onComplete(@NonNull Task <AuthResult> task) {
                        Toast.makeText(AlumniFormActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                        ProgressBarAlum.setVisibility(View.GONE);
                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Toast.makeText(AlumniFormActivity.this, "Authentication failed." + task.getException(),
                                           Toast.LENGTH_SHORT).show();
                            Log.d("--Debug","The email id is: "+email);
                        } else {
                            CompanyAddress addr=new CompanyAddress(latitude,longitude,companyAddress.getText().toString().trim());
                            Alumni alumni=new Alumni(firstName,lastName,email,password,graduatedDate,linkedProfile,domain,company,addr);
                            //This task will be executed on a different thread.
                            new AlumniDBWriteTask(alumni).execute();
                        }
                    }
                });
            }
        });

    }
    //Async Task for data writing to database.
    private class AlumniDBWriteTask extends AsyncTask<Void, Void, Alumni>
    {
        Alumni alumni;
        public AlumniDBWriteTask(Alumni alumni){
            this.alumni = alumni;
        }

        @Override
        protected Alumni doInBackground(Void... voids) {
            String id=databaseRefAlumni.push().getKey();
            databaseRefAlumni.child(id).setValue(alumni);
            startActivity(new Intent(AlumniFormActivity.this, HomeActivity.class));
            finish();
            return null;
        }
    }

}
