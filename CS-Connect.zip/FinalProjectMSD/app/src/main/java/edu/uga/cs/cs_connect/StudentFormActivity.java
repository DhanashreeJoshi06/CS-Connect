package edu.uga.cs.cs_connect;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class StudentFormActivity extends AppCompatActivity {

    Button create;
    EditText FirstNameStudent,LastNameStudent,EmailStud,PasswordStud,ConfirmPassStud,gradDateStud;
    Spinner spinnerStud;
    ProgressBar progressBarStud;
    private FirebaseAuth mAuth;

    DatabaseReference databaseRefStudent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_form);

        FirebaseApp.initializeApp(StudentFormActivity.this);
        mAuth = FirebaseAuth.getInstance();

        create = findViewById(R.id.btn_login);
        FirstNameStudent = findViewById(R.id.FirstNameAlum);
        LastNameStudent = findViewById(R.id.LastnameAlum);
        EmailStud = findViewById(R.id.emailAlum);
        PasswordStud = findViewById(R.id.PassAlum);
        ConfirmPassStud = findViewById(R.id.ConfirmPassAlum);
        gradDateStud = findViewById(R.id.gradDateAlum);
        spinnerStud = findViewById(R.id.spinnerstud);
        progressBarStud = findViewById(R.id.progressBarStud);

        String[] arraySpinner = new String[] {
                "Data Science", "Cloud","DevOps Engineer","Big Data","Machine Learning", "Software Engineer", "Mobile Developer"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arraySpinner);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStud.setAdapter(adapter);

        databaseRefStudent= FirebaseDatabase.getInstance().getReference("Student");

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                final String firstname = FirstNameStudent.getText().toString().trim();
                final String lastname = LastNameStudent.getText().toString().trim();
                final String email = EmailStud.getText().toString().trim();
                final String password = PasswordStud.getText().toString().trim();
                String confirmpassword = ConfirmPassStud.getText().toString().trim();
                final String graduationDate = gradDateStud.getText().toString().trim();
                final String domain = spinnerStud.getSelectedItem().toString().trim();



                if (TextUtils.isEmpty(firstname)) {
                    Toast.makeText(getApplicationContext(), "Enter First Name", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(lastname)) {
                    Toast.makeText(getApplicationContext(), "Enter Last Name!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(confirmpassword)) {
                    Toast.makeText(getApplicationContext(), "Enter Password again for confirmation", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Checking whether the password entered is same as password entered for confirmation
                if(!TextUtils.equals(password,confirmpassword)){
                    Toast.makeText(getApplicationContext(),"Please enter the same password for confirmation",Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBarStud.setVisibility(View.VISIBLE);
                //Create the StudentUser
                mAuth.createUserWithEmailAndPassword(email,confirmpassword)
                        .addOnCompleteListener(StudentFormActivity.this, new OnCompleteListener <AuthResult>( ) {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        Toast.makeText(StudentFormActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                        progressBarStud.setVisibility(View.GONE);
                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (!task.isSuccessful()) {
                            Toast.makeText(StudentFormActivity.this, "Authentication failed." + task.getException(),
                                           Toast.LENGTH_SHORT).show();
                        } else {
                            Log.d("--Debug","I am in else part");
                            Student student=new Student(firstname,lastname,email,password,graduationDate,domain);
                            //Perform Async task on other thread
                            new StudentDBWriteTask(student).execute();
                        }
                    }
                });
            }
        });
    }

    private class StudentDBWriteTask extends AsyncTask<Void,Void,Void>{
        private Student student;
        public StudentDBWriteTask(Student student){
            this.student = student;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            Log.d("--Debug","Performing Async Task");
            String id=databaseRefStudent.push().getKey();
            databaseRefStudent.child(id).setValue(student);
            startActivity(new Intent(StudentFormActivity.this, HomeActivity.class));
            finish();
            return null;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBarStud.setVisibility(View.GONE);
    }
}
