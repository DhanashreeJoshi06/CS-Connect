package edu.uga.cs.cs_connect;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.InfoWindowAdapter
{
    Button logout;
    DatabaseReference firebaseAlumniRef;
    private GoogleMap mMap;
    List<CompanyAddress> latLong=new ArrayList<>();
    List<Alumni> alumniList=new ArrayList<>();
    Map<Marker, Alumni> markerMap = new HashMap<>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("*****Inside OnCreate*****");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap)
    {
        System.out.println("*****Inside OnMapReady*****");
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        logout = findViewById(R.id.logout);

        firebaseAlumniRef = FirebaseDatabase.getInstance().getReference("Alumni");
        firebaseAlumniRef.addValueEventListener(new ValueEventListener()
        {
            //every time data is changed
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                for(DataSnapshot alumniSnapshot: dataSnapshot.getChildren())
                {
                    CompanyAddress coord=new CompanyAddress();
                    Alumni alumni=alumniSnapshot.getValue(Alumni.class);
                    alumniList.add(alumni);
                    coord.setLatitude(alumni.getAddressDetails().getLatitude());
                    coord.setLongitude(alumni.getAddressDetails().getLongitude());
                    latLong.add(coord);
                }


                for (int i = 0; i < latLong.size(); i++)
                {
                    System.out.println("*****Coordinates*****");
                    System.out.println("Lat: "+latLong.get(i).getLatitude());
                    System.out.println("Long: "+latLong.get(i).getLongitude());
                    System.out.println();

                    Marker marker=mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(Double.parseDouble(latLong.get(i).getLatitude()), Double.parseDouble(latLong.get(i).getLongitude())))
                    .title(alumniList.get(i).getFirstName()+" "+alumniList.get(i).getLastName()));

                    markerMap.put(marker, alumniList.get(i));

                    for (Map.Entry<Marker, Alumni> item : markerMap.entrySet()) {
                        //String key = item.getKey();
                        Alumni value = item.getValue();
                        System.out.println("---MAPS---");
                        System.out.println(value.getLinkedInProfile());
                    }

                    mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                        @Override
                        public boolean onMarkerClick(Marker marker)
                        {

                            AlertDialog.Builder builder = new AlertDialog.Builder(MapsActivity.this);

                            Alumni alumni = markerMap.get(marker);

                            //SpannableString spanMsg = new SpannableString(msg);

//                            TextView text =new TextView(getApplicationContext());
//                            text.setText(alumni.getLinkedInProfile());
//                            Linkify.addLinks(text,Linkify.WEB_URLS);
//                            text.setMovementMethod(LinkMovementMethod.getInstance());

                            //String linkedIn=text.getText().toString();




                            String message="<html><br><br><font color='#74B804'>COMPANY : </font>"+alumni.getCompanyName().toUpperCase()+"<br><br><font color='#74B804'>WORK DOMAIN: </font><br>"+alumni.getDomain()+"<br><br><font color='#74B804'>ALUMNI_EMAIL: </font>"+alumni.getEmail().toLowerCase()+"<br><br><font color='#74B804'>GRADUATED: </font>"+alumni.getGraduatedDate()+"<br><br><font color='#74B804'>LinkedIn: </font><a href="+alumni.getLinkedInProfile()+">Visit LinkedIn Profile"+"</a>";


                            final SpannableString s = new SpannableString(message);
                            Linkify.addLinks(s, Linkify.ALL);


                            String alumniName="<html><font size=+10 color='#1435EF'><b>"+alumni.getFirstName()+" "+alumni.getLastName()+"</html>";
                            builder.setTitle(Html.fromHtml(alumniName.toUpperCase()));
                            builder.setMessage(Html.fromHtml(message));

                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });

                            AlertDialog dialog = builder.create();
                            dialog.show();
                            ((TextView)dialog.findViewById(android.R.id.message)).setMovementMethod(LinkMovementMethod.getInstance());

                            if(alumni != null)
                            {
                                Log.d("test", ""+alumni.getFirstName()+" is clicked");
                                Log.d("test", ""+alumni.getLastName()+" is clicked");
                                Log.d("test", ""+alumni.getCompanyName()+" is clicked");
                                Log.d("test", ""+alumni.getDomain()+" is clicked");
                                Log.d("test", ""+alumni.getGraduatedDate()+" is clicked");
                                Log.d("test", ""+alumni.getAddressDetails().getAddress()+" is clicked");
                            }
                            return false;
                        }
                    });

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {
                Log.w("EXCEPTION",""+databaseError.getMessage());

            }
        });
        logout.setOnClickListener(new View.OnClickListener( ) {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MapsActivity.this,HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public View getInfoWindow(Marker marker)
    {

        return null;
    }

    @Override
    public View getInfoContents(Marker marker) {
        return null;
    }
}
